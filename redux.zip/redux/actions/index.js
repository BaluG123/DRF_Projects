import { ADD_TODO, REMOVE_TODO, EDIT_TODO } from './types';

export const addTodo = (todo) => ({
  type: ADD_TODO,
  payload: todo
});

export const removeTodo = (index) => ({
  type: REMOVE_TODO,
  payload: index
});

export const editTodo = (index,newTodo) => ({
    type: EDIT_TODO,
    payload: {index,newTodo}
})


// ABOVE CODE IS FOR normal todo , without API

// actions/index.js 
// below code is when API is there 

// import { ADD_TODO, REMOVE_TODO, EDIT_TODO, SET_TODOS } from './types';

// const API_URL = 'http://localhost:8000/api/todos/';

// export const setTodos = (todos) => ({
//   type: SET_TODOS,
//   payload: todos,
// });

// export const fetchTodos = () => {
//   return async (dispatch) => {
//     const response = await fetch(API_URL);
//     const todos = await response.json();
//     dispatch(setTodos(todos));
//   };
// };

// export const addTodo = (text) => {
//   return async (dispatch) => {
//     const response = await fetch(API_URL, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ text }),
//     });
//     const todo = await response.json();
//     dispatch({
//       type: ADD_TODO,
//       payload: todo,
//     });
//   };
// };

// export const removeTodo = (id) => {
//   return async (dispatch) => {
//     await fetch(`${API_URL}${id}/`, {
//       method: 'DELETE',
//     });
//     dispatch({
//       type: REMOVE_TODO,
//       payload: id,
//     });
//   };
// };

// export const editTodo = (id, newTodo) => {
//   return async (dispatch) => {
//     const response = await fetch(`${API_URL}${id}/`, {
//       method: 'PUT',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ text: newTodo }),
//     });
//     const todo = await response.json();
//     dispatch({
//       type: EDIT_TODO,
//       payload: todo,
//     });
//   };
// };
