import { ADD_TODO,REMOVE_TODO,EDIT_TODO } from "../actions/types";

const initialState = {
    todos: []
  };
  
  const todoReducer = (state = initialState, action) => {
    switch (action.type) {
      case ADD_TODO:
        return { ...state, todos: [...state.todos, action.payload] };
      case REMOVE_TODO:
        return { ...state, todos: state.todos.filter((_, index) => index !== action.payload) };
      case EDIT_TODO:
        case EDIT_TODO:
        const updatedTodos = state.todos.map((todo, index) =>
        index === action.payload.index ? action.payload.newTodo : todo
      );
      return { ...state, todos: updatedTodos };
      default:
        return state;
    }
  };
  
  export default todoReducer;

/*********** above code is when no API's are there */

// reducers/todoReducer.js
/**** is for when API is there  */

// import { ADD_TODO, REMOVE_TODO, EDIT_TODO, SET_TODOS } from '../actions/types';

// const initialState = {
//   todos: [],
// };

// const todoReducer = (state = initialState, action) => {
//   switch (action.type) {
//     case SET_TODOS:
//       return { ...state, todos: action.payload };
//     case ADD_TODO:
//       return { ...state, todos: [...state.todos, action.payload] };
//     case REMOVE_TODO:
//       return { ...state, todos: state.todos.filter((todo) => todo.id !== action.payload) };
//     case EDIT_TODO:
//       return {
//         ...state,
//         todos: state.todos.map((todo) => (todo.id === action.payload.id ? action.payload : todo)),
//       };
//     default:
//       return state;
//   }
// };

// export default todoReducer;
